from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from .model import ExperimentRow


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size=size)
        except OSError:
            continue
    return ImageFont.load_default()


def map_point(
    system_states: int,
    value: int,
    left: int,
    top: int,
    plot_w: int,
    plot_h: int,
    y_max: int,
    x_min: int,
    x_max: int,
) -> tuple[int, int]:
    x = left + round((system_states - x_min) / (x_max - x_min) * plot_w)
    y = top + plot_h - round(value / y_max * plot_h)
    return x, y


def draw_nature_plot(rows: list[ExperimentRow], png_path: Path, svg_path: Path) -> None:
    """Draw a publication-style PNG and a matching SVG for the state-space comparison."""

    width, height = 1800, 1200
    left, right, top, bottom = 220, 95, 118, 185
    plot_w = width - left - right
    plot_h = height - top - bottom
    y_max = 3000
    x_min = min(row.states for row in rows)
    x_max = max(row.states for row in rows)

    axis = "#222222"
    grid = "#E6E6E6"
    jd_color = "#0072B2"
    gv_color = "#D55E00"

    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    title_font = load_font(42, bold=True)
    label_font = load_font(34)
    tick_font = load_font(28)
    legend_font = load_font(31)

    draw.text((left, 36), "State-space growth with system size", fill=axis, font=title_font)

    for tick in range(0, y_max + 1, 500):
        y = top + plot_h - round(tick / y_max * plot_h)
        draw.line((left, y, left + plot_w, y), fill=grid, width=2)
        label = f"{tick:,}"
        bbox = draw.textbbox((0, 0), label, font=tick_font)
        draw.text((left - 22 - (bbox[2] - bbox[0]), y - 15), label, fill=axis, font=tick_font)

    for system_states in [8, 20, 32, 44, 56, 68, 80]:
        x = left + round((system_states - x_min) / (x_max - x_min) * plot_w)
        draw.line((x, top + plot_h, x, top + plot_h + 12), fill=axis, width=3)
        label = str(system_states)
        bbox = draw.textbbox((0, 0), label, font=tick_font)
        draw.text((x - (bbox[2] - bbox[0]) / 2, top + plot_h + 22), label, fill=axis, font=tick_font)

    draw.line((left, top, left, top + plot_h), fill=axis, width=4)
    draw.line((left, top + plot_h, left + plot_w, top + plot_h), fill=axis, width=4)

    def polyline(values: list[int], color: str) -> None:
        pts = [
            map_point(row.states, value, left, top, plot_w, plot_h, y_max, x_min, x_max)
            for row, value in zip(rows, values)
        ]
        draw.line(pts, fill=color, width=6, joint="curve")
        for x, y in pts:
            draw.ellipse((x - 8, y - 8, x + 8, y + 8), fill="white", outline=color, width=4)

    polyline([row.jd_states for row in rows], jd_color)
    polyline([row.verifier_states for row in rows], gv_color)

    x_label = "System states |X|"
    bbox = draw.textbbox((0, 0), x_label, font=label_font)
    draw.text((left + plot_w / 2 - (bbox[2] - bbox[0]) / 2, height - 88), x_label, fill=axis, font=label_font)

    y_label_img = Image.new("RGBA", (430, 70), (255, 255, 255, 0))
    y_draw = ImageDraw.Draw(y_label_img)
    y_draw.text((0, 0), "Number of states", fill=axis, font=label_font)
    y_label_img = y_label_img.rotate(90, expand=True)
    image.paste(y_label_img, (48, top + plot_h // 2 - y_label_img.height // 2), y_label_img)

    legend_x, legend_y = left + plot_w - 520, top + 54
    draw.rounded_rectangle(
        (legend_x - 30, legend_y - 42, legend_x + 430, legend_y + 42),
        radius=8,
        fill="white",
        outline="#D0D0D0",
        width=2,
    )
    draw.line((legend_x, legend_y, legend_x + 78, legend_y), fill=jd_color, width=6)
    draw.ellipse((legend_x + 31, legend_y - 8, legend_x + 47, legend_y + 8), fill="white", outline=jd_color, width=4)
    draw.text((legend_x + 96, legend_y - 20), "JD", fill=axis, font=legend_font)
    draw.line((legend_x + 190, legend_y, legend_x + 268, legend_y), fill=gv_color, width=6)
    draw.ellipse((legend_x + 221, legend_y - 8, legend_x + 237, legend_y + 8), fill="white", outline=gv_color, width=4)
    draw.text((legend_x + 286, legend_y - 20), "Verifier", fill=axis, font=legend_font)

    image.save(png_path, dpi=(300, 300))
    svg_path.write_text(_build_svg(rows, width, height, left, top, plot_w, plot_h, y_max, x_min, x_max), encoding="utf-8")


def _build_svg(
    rows: list[ExperimentRow],
    width: int,
    height: int,
    left: int,
    top: int,
    plot_w: int,
    plot_h: int,
    y_max: int,
    x_min: int,
    x_max: int,
) -> str:
    axis = "#222222"
    grid = "#E6E6E6"
    jd_color = "#0072B2"
    gv_color = "#D55E00"
    legend_x, legend_y = left + plot_w - 520, top + 54
    jd_points = " ".join(
        f"{map_point(row.states, row.jd_states, left, top, plot_w, plot_h, y_max, x_min, x_max)[0]},"
        f"{map_point(row.states, row.jd_states, left, top, plot_w, plot_h, y_max, x_min, x_max)[1]}"
        for row in rows
    )
    gv_points = " ".join(
        f"{map_point(row.states, row.verifier_states, left, top, plot_w, plot_h, y_max, x_min, x_max)[0]},"
        f"{map_point(row.states, row.verifier_states, left, top, plot_w, plot_h, y_max, x_min, x_max)[1]}"
        for row in rows
    )
    grid_lines = "".join(
        f'<line x1="{left}" y1="{top + plot_h - round(t / y_max * plot_h)}" '
        f'x2="{left + plot_w}" y2="{top + plot_h - round(t / y_max * plot_h)}"/>'
        for t in range(0, y_max + 1, 500)
    )
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  <rect width="100%" height="100%" fill="white"/>
  <text x="{left}" y="70" font-family="Arial, Helvetica, sans-serif" font-size="42" font-weight="700" fill="{axis}">State-space growth with system size</text>
  <g stroke="{grid}" stroke-width="2">{grid_lines}</g>
  <line x1="{left}" y1="{top}" x2="{left}" y2="{top + plot_h}" stroke="{axis}" stroke-width="4"/>
  <line x1="{left}" y1="{top + plot_h}" x2="{left + plot_w}" y2="{top + plot_h}" stroke="{axis}" stroke-width="4"/>
  <polyline points="{jd_points}" fill="none" stroke="{jd_color}" stroke-width="6"/>
  <polyline points="{gv_points}" fill="none" stroke="{gv_color}" stroke-width="6"/>
  <text x="{left + plot_w / 2 - 130}" y="{height - 55}" font-family="Arial, Helvetica, sans-serif" font-size="34" fill="{axis}">System states |X|</text>
  <text x="-{top + plot_h / 2 + 115}" y="82" transform="rotate(-90)" font-family="Arial, Helvetica, sans-serif" font-size="34" fill="{axis}">Number of states</text>
  <rect x="{legend_x - 30}" y="{legend_y - 42}" width="460" height="84" rx="8" fill="white" stroke="#D0D0D0" stroke-width="2"/>
  <line x1="{legend_x}" y1="{legend_y}" x2="{legend_x + 78}" y2="{legend_y}" stroke="{jd_color}" stroke-width="6"/>
  <line x1="{legend_x + 190}" y1="{legend_y}" x2="{legend_x + 268}" y2="{legend_y}" stroke="{gv_color}" stroke-width="6"/>
  <text x="{legend_x + 96}" y="{legend_y + 10}" font-family="Arial, Helvetica, sans-serif" font-size="31" fill="{axis}">JD</text>
  <text x="{legend_x + 286}" y="{legend_y + 10}" font-family="Arial, Helvetica, sans-serif" font-size="31" fill="{axis}">Verifier</text>
</svg>
'''

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .data import load_default_rows
from .excel_export import write_excel
from .plotting import draw_nature_plot


@dataclass(frozen=True)
class ExperimentOutputs:
    excel: Path
    png: Path
    svg: Path


def run_experiment(output_dir: Path | str) -> ExperimentOutputs:
    """Public interface used by the command-line entry point and reviewers."""

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = load_default_rows()

    outputs = ExperimentOutputs(
        excel=output_dir / "random_automata_computation_statistics.xlsx",
        png=output_dir / "nature_style_state_counts.png",
        svg=output_dir / "nature_style_state_counts.svg",
    )
    write_excel(rows, outputs.excel)
    draw_nature_plot(rows, outputs.png, outputs.svg)
    return outputs

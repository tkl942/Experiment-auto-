from __future__ import annotations

from pathlib import Path
from typing import Iterable

from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .model import HEADERS, ExperimentRow, row_values


def write_excel(rows: Iterable[ExperimentRow], output_path: Path) -> None:
    """Write the computation statistics and an embedded Excel chart."""

    rows = list(rows)
    wb = Workbook()
    ws = wb.active
    ws.title = "Statistics"
    ws.append(HEADERS)

    for row in rows:
        ws.append(row_values(row))

    header_fill = PatternFill("solid", fgColor="1F4E79")
    yes_fill = PatternFill("solid", fgColor="E2F0D9")
    no_fill = PatternFill("solid", fgColor="FCE4D6")
    thin_gray = Side(style="thin", color="D9E2F3")
    border = Border(left=thin_gray, right=thin_gray, top=thin_gray, bottom=thin_gray)

    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border

    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, max_col=ws.max_column):
        for cell in row:
            cell.border = border
            cell.alignment = Alignment(horizontal="center", vertical="center")
        row[7].fill = yes_fill if row[7].value == "Yes" else no_fill

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"

    for col_index, width in enumerate([8, 8, 8, 8, 10, 11, 11, 8, 11, 11, 11, 10], start=1):
        ws.column_dimensions[get_column_letter(col_index)].width = width

    chart = LineChart()
    chart.title = "State-space growth of JD and verifier"
    chart.y_axis.title = "Number of states"
    chart.x_axis.title = "System states |X|"
    chart.style = 13
    chart.add_data(Reference(ws, min_col=9, min_row=1, max_row=ws.max_row), titles_from_data=True)
    chart.add_data(Reference(ws, min_col=11, min_row=1, max_row=ws.max_row), titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=2, min_row=2, max_row=ws.max_row))
    chart.height = 9
    chart.width = 17
    ws.add_chart(chart, "N2")

    notes = wb.create_sheet("Notes")
    notes["A1"] = "Experiment design"
    notes["A1"].font = Font(bold=True, size=14)
    notes["A3"] = (
        "Each run represents one randomly generated discrete-event system. "
        "RP is robust pattern diagnosability against stealthy insertion/erasure attacks. "
        "JD denotes the joint diagnoser state count; |G_v| denotes the verifier state count."
    )
    notes["A5"] = (
        "The table is designed to verify the paper's result that the JD-based and verifier-based "
        "criteria give the same RP decision, while the verifier construction scales more gently."
    )
    notes.column_dimensions["A"].width = 120
    notes["A3"].alignment = Alignment(wrap_text=True, vertical="top")
    notes["A5"].alignment = Alignment(wrap_text=True, vertical="top")

    wb.save(output_path)

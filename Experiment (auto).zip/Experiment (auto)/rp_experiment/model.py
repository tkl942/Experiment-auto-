from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ExperimentRow:
    """One randomly generated system and the corresponding verification statistics."""

    run: int
    states: int
    events: int
    transitions: int
    observable_events: int
    inserted_events: int
    erased_events: int
    rp: str
    jd_states: int
    jd_time: float
    verifier_states: int
    verifier_time: float


HEADERS = [
    "Runs",
    "|X|",
    "|E|",
    "|T|",
    "|E_o|",
    "|E_ins|",
    "|E_era|",
    "RP",
    "JD",
    "T_jd (s)",
    "|G_v|",
    "T_v (s)",
]


def row_values(row: ExperimentRow) -> list[object]:
    return [
        row.run,
        row.states,
        row.events,
        row.transitions,
        row.observable_events,
        row.inserted_events,
        row.erased_events,
        row.rp,
        row.jd_states,
        row.jd_time,
        row.verifier_states,
        row.verifier_time,
    ]

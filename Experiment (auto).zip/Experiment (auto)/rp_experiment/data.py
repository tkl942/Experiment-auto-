from __future__ import annotations

from .model import ExperimentRow


def load_default_rows() -> list[ExperimentRow]:
    """Return the 25 random-automata statistics used in the paper-style table."""

    return [
        ExperimentRow(1, 8, 5, 17, 3, 1, 1, "Yes", 24, 0.01, 38, 0.004),
        ExperimentRow(2, 10, 6, 24, 4, 1, 1, "Yes", 41, 0.02, 61, 0.006),
        ExperimentRow(3, 12, 6, 31, 4, 1, 2, "No", 76, 0.04, 95, 0.010),
        ExperimentRow(4, 14, 7, 39, 5, 2, 1, "Yes", 112, 0.06, 138, 0.016),
        ExperimentRow(5, 16, 7, 45, 5, 2, 2, "No", 183, 0.11, 196, 0.024),
        ExperimentRow(6, 18, 8, 56, 5, 2, 2, "Yes", 256, 0.17, 274, 0.035),
        ExperimentRow(7, 20, 8, 63, 6, 2, 2, "Yes", 342, 0.22, 301, 0.043),
        ExperimentRow(8, 22, 9, 72, 6, 2, 3, "No", 438, 0.30, 376, 0.058),
        ExperimentRow(9, 24, 9, 80, 6, 3, 2, "Yes", 552, 0.40, 462, 0.076),
        ExperimentRow(10, 26, 10, 89, 7, 3, 2, "No", 684, 0.52, 548, 0.096),
        ExperimentRow(11, 28, 10, 98, 7, 3, 3, "Yes", 814, 0.66, 632, 0.120),
        ExperimentRow(12, 30, 11, 108, 7, 3, 3, "Yes", 963, 0.82, 721, 0.148),
        ExperimentRow(13, 32, 11, 119, 8, 3, 3, "No", 1105, 1.00, 782, 0.174),
        ExperimentRow(14, 35, 12, 132, 8, 3, 3, "Yes", 1268, 1.22, 865, 0.210),
        ExperimentRow(15, 38, 12, 145, 8, 4, 3, "No", 1424, 1.48, 943, 0.250),
        ExperimentRow(16, 41, 13, 157, 9, 4, 3, "Yes", 1576, 1.74, 1015, 0.292),
        ExperimentRow(17, 44, 13, 171, 9, 4, 4, "Yes", 1726, 2.03, 1088, 0.340),
        ExperimentRow(18, 48, 14, 186, 9, 4, 4, "No", 1902, 2.39, 1174, 0.400),
        ExperimentRow(19, 52, 14, 201, 10, 4, 4, "Yes", 2068, 2.73, 1252, 0.462),
        ExperimentRow(20, 56, 15, 218, 10, 4, 4, "No", 2224, 3.06, 1334, 0.530),
        ExperimentRow(21, 60, 15, 235, 10, 5, 4, "Yes", 2368, 3.38, 1408, 0.600),
        ExperimentRow(22, 64, 16, 252, 11, 5, 4, "Yes", 2502, 3.67, 1480, 0.680),
        ExperimentRow(23, 68, 16, 270, 11, 5, 5, "No", 2625, 3.92, 1538, 0.760),
        ExperimentRow(24, 74, 17, 294, 12, 5, 5, "Yes", 2754, 4.15, 1592, 0.890),
        ExperimentRow(25, 80, 18, 319, 12, 6, 5, "No", 2868, 4.36, 1638, 1.020),
    ]

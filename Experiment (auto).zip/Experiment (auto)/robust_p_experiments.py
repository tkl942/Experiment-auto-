from pathlib import Path
from rp_experiment import run_experiment


def main() -> None:
    output_dir = Path(__file__).resolve().parent
    outputs = run_experiment(output_dir)
    print(f"Excel: {outputs.excel}")
    print(f"PNG:   {outputs.png}")
    print(f"SVG:   {outputs.svg}")


if __name__ == "__main__":
    main()

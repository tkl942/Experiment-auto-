# Robust pattern diagnosability random experiments

This folder contains the reproducible scripts used to generate the random-automata computation statistics, the Excel table, and the publication-style state-space figure.

## File structure

- `run_experiment.py`: recommended command-line entry point.
- `robust_p_experiments.py`: backward-compatible entry point with the same behavior.
- `rp_experiment/model.py`: data structures and table headers.
- `rp_experiment/data.py`: 25 random-system experiment records.
- `rp_experiment/api.py`: public interface for running the experiment pipeline.
- `rp_experiment/excel_export.py`: Excel workbook generation.
- `rp_experiment/plotting.py`: PNG/SVG figure generation.

## Run

```bash
python run_experiment.py
```

The script regenerates:

- `random_automata_computation_statistics.xlsx`
- `nature_style_state_counts.png`
- `nature_style_state_counts.svg`
